create view v_ton_kho_hien_tai
            (ma_nguyen_lieu, ten_nguyen_lieu, don_vi_tinh, tong_ton, muc_ton_toi_thieu, canh_bao_ton_thap) as
SELECT nl.ma_nguyen_lieu,
       nl.ten_nguyen_lieu,
       nl.don_vi_tinh,
       COALESCE(sum(l.so_luong), 0::numeric) AS tong_ton,
       nl.muc_ton_toi_thieu,
       CASE
           WHEN COALESCE(sum(l.so_luong), 0::numeric) < nl.muc_ton_toi_thieu THEN true
           ELSE false
           END                               AS canh_bao_ton_thap
FROM wms.nguyen_lieu nl
         LEFT JOIN wms.lo_nguyen_lieu l ON l.ma_nguyen_lieu::text = nl.ma_nguyen_lieu::text AND (l.trang_thai = ANY
                                                                                                 (ARRAY ['MOI'::wms.trang_thai_lo, 'DANG_SU_DUNG'::wms.trang_thai_lo]))
GROUP BY nl.ma_nguyen_lieu, nl.ten_nguyen_lieu, nl.don_vi_tinh, nl.muc_ton_toi_thieu;

alter table v_ton_kho_hien_tai
    owner to postgres;

